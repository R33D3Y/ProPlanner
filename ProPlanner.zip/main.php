<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

$main = new Main();

class Main
{
	private $username;
	private $firstname;
	private $lastname;
	private $email;
	private $password;

	private $servername = "localhost";
	private $serverUsername = "root";
	private $serverPassword = "myserver2708";

	private $member;
	private $account;

	private $connection;

	public function main()
	{
		$this->checkConnection();
		$this->createDatabase();
		$this->useDatabase();
		$this->createTables();

		session_start();

		if (isset($_SESSION["logged"]))
		{
			//echo "Session";
			$this->username = $_SESSION["username"];
			$this->password = $_SESSION["password"];
			$_SESSION["lists"] = $this->getLists();
			$_SESSION["list"] = 0;

			if (isset($_POST['logout']))
			{
				$_SESSION["logged"] = 0;
				session_destroy();
				header('Location: /Programming/MySQL/Jack(OOP)/index.html');
			}

			else if (isset($_POST['refresh']))
			{
				header('Location: /Programming/MySQL/Jack(OOP)/main.php');
			}

			else if (isset($_POST['addList']))
			{
				if ($_POST['name'] !== "")
				{
					$toDoList = new ToDoList($this->connection);
					$toDoList->addList($_POST['name'], $_POST['colour'], $_POST['category']);
				}
			}

			else if (isset($_POST['addTask']))
			{
				if ($_POST['content'] !== "")
				{
					$time = "";
					$deadline = "";
					$type = "";

					if (strpos($_POST['type'], "timer") !== false)
					{
						$time = $_POST['taskTime'];
						$type = "timer";
					}

					else if (strpos($_POST['type'], "deadline") !== false)
					{
						$deadline = $_POST['taskDate'];
						$type = "deadline";
					}

					$task = new Task($this->connection);
					$task->addTask($_POST['listID'], $type, $deadline, $time, $_POST['content']);
				}
			}

			$countState = -1;

			while (++$countState <= 20)
			{
				if (isset($_POST['state'.$countState]))
				{
					$task = new Task($this->connection);
					$task->changeTaskState($countState);
				}
			}

			$countRemove = -1;

			while (++$countRemove <= 20)
			{
				if (isset($_POST['removeTask'.$countRemove]))
				{
					$task = new Task($this->connection);
					$task->removeTask($countRemove);
				}
			}

			$countRemoveList = -1;

			while (++$countRemoveList <= 20)
			{
				if (isset($_POST['removeList'.$countRemoveList]))
				{
					$toDoList = new ToDoList($this->connection);
					$toDoList->removeList($countRemoveList);
				}
			}

			$this->displayPage();
		}
		
		else 
		{
			$this->username = strtolower($_POST["username"]);
			$this->password = $_POST["password"];

			if (isset($_POST['login']))
			{
				//echo "Member";
				$member = new Member($this->connection, $this->username, $this->password);

				$_SESSION["logged"] = 1;
				$_SESSION["username"] = $this->username;
				$_SESSION["password"] = $this->password;
				$_SESSION["lists"] = $this->getLists();
				$_SESSION["list"] = 0;
				$this->displayPage();
			}

			else if (isset($_POST['register']))
			{
				//echo "Account";
				$this->firstname = strtolower($_POST["firstname"]);
				$this->lastname = strtolower($_POST["lastname"]);
				$this->email = strtolower($_POST["email"]);

				$account = new Account($this->connection, $this->username, $this->firstname, $this->lastname, $this->email, $this->password);

				$_SESSION["logged"] = 1;
				$_SESSION["username"] = $this->username;
				$_SESSION["password"] = $this->password;
				$_SESSION["lists"] = $this->getLists();
				$_SESSION["list"] = 0;

				$this->displayPage();
			}

			else
			{
				session_destroy();
				header('Location: /Programming/MySQL/Jack(OOP)/index.html');
			}
		}
	}

	private function getLists()
	{
		$sql = "SELECT lists FROM users WHERE username = '$this->username'";
		$result = $this->connection->query($sql);
		$result1 = $result->fetch_assoc();
		return $result1['lists'];
	}

	private function checkConnection()
	{
		$this->connection = new mysqli($this->servername, $this->serverUsername, $this->serverPassword);
		// Check connection
		if ($this->connection->connect_error)
		{
			die("Connection failed: " . $this->connection->connect_error);
		}
	}

	private function createDatabase()
	{
		$sql = "CREATE DATABASE SEP";

		$this->connection->query($sql);
	}

	private function useDatabase()
	{
		$sql = "USE SEP";

		$this->connection->query($sql);
	}

	private function createTables()
	{
		//Users
		$sql = "CREATE TABLE users (username VARCHAR(30), firstname VARCHAR(30), lastname VARCHAR(30), email VARCHAR(50), password VARCHAR(30), lists INT(6), points INT(6))";

		$this->connection->query($sql);

		//Lists
		$sql = "CREATE TABLE lists (id INT(6), username VARCHAR(30), name VARCHAR(100), colour VARCHAR(100), category VARCHAR(100))";

		$this->connection->query($sql);

		//Tasks
		$sql = "CREATE TABLE tasks (id INT(6), listID INT(6), state BOOLEAN, type VARCHAR(15), taskDate VARCHAR(25), taskTime VARCHAR(25), content VARCHAR(100))";

		$this->connection->query($sql);
	}

	private function displayPage()
	{
		?>

		<!DOCTYPE html>
		<html>
			<head>
				<meta name="viewport" content="width=device-width, initial-scale=1">
				<link rel="stylesheet" type="text/css" href="tasks.css">
				<link href='https://fonts.googleapis.com/css?family=Amiko' rel='stylesheet'>
				<link rel='stylesheet' href='style.css' />
				<link rel='stylesheet' href='js/spectrum.css' />
				<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
				<title>Your Tasks</title>
				<script type="text/javascript" src="js/jquery.js"></script>
				<script type="text/javascript" src="js/spectrum.js"></script>
				<script type="text/javascript" src="javascript.js"></script>

				<script type="text/javascript">
 
					window.onload = function()
					{
						hideElements();
						hideLists();
					};

					function hideElements()
					{
						var count = 0;

						do 
						{
							if (document.getElementById('divDate' + count) != null && document.getElementById('divTime' + count) != null)
							{
								document.getElementById('divDate' + count).style.display = 'none';
								document.getElementById('divTime' + count).style.display = 'none';
							}
						} while (count++ <= 5);
					}

					function hideLists()
					{
						var count = 0;

						do 
						{
							if (document.getElementById('panel' + count) != null)
							{
								//document.getElementById('panel' + count).style.display = 'block';
							}
						} while (count++ <= 5);
					}

					function showHide(elem)
					{
						var count = 0;

						do
						{
							if (elem.value == ("timer" + count))
							{
								document.getElementById('divDate' + count).style.display = 'none';
								document.getElementById('divTime' + count).style.display = 'block';
							}

							else if (elem.value == ("deadline" + count))
							{
								document.getElementById('divTime' + count).style.display = 'none';
								document.getElementById('divDate' + count).style.display = 'block';
							}

							else
							{
								document.getElementById('divDate' + count).style.display = 'none';
								document.getElementById('divTime' + count).style.display = 'none';
							}
						} while(count++ <= 5);
					}

					function clickLists(elem)
					{
						var count = 0;

						do
						{
							if (elem.value == ("list" + count))
							{
						        if (document.getElementById('panel' + count).style.display == 'block')
						        {
						            document.getElementById('panel' + count).style.display = 'none';
						        }

						        else
						        {
						            document.getElementById('panel' + count).style.display = 'block';
						        }
					    	}
						} while(count++ <= 5);
					}
				</script>
			</head>

			<body>
				<div class="page2">
					<div class="col">
						<div class="top">
							<form style="text-align: right" action="main.php" method="post">
								<?php
									echo "<p>Points: ".$this->getPoints()."</p>";
									echo "<input type='submit' name='refresh' value='\u{1F503}'>";
								?>
								<input type="submit" name="logout" value="Log Out">
							</form>
						</div>
						<?php
							$this->displayLists();
						?>
					</div>
				</div>
			</body>
		</html>

		<?php
	}

	private function getPoints()
	{
		$sql = "SELECT points FROM users WHERE username = '$this->username'";
		$result = $this->connection->query($sql);
		$result1 = $result->fetch_assoc();
		return $result1['points'];
	}

	private function listBorder($colour)
	{
		return "border-style: none; border-bottom-style: solid;border-color: ".$colour.";";
	}

	private function listBorderFade($colour)
	{
		return "border-color: linear-gradient(to left,".$colour.", black);background: linear-gradient(to left,".$colour.", black);";
	}

	private function displayLists()
	{
		$sql = "SELECT id, name, colour, category FROM lists WHERE username = '$this->username'";
		$result = $this->connection->query($sql);

		echo "<div class='container'>";
		
		if ($result->num_rows > 0)
		{
			$count = 0;

			while ($result1 = $result->fetch_assoc())
			{
				echo "<div class='listButton'>";
				echo "<button class='list' id='list".$count."' style='".$this->listBorderFade($result1['colour'])."' onclick='clickLists(this)' value='list".$count."'>".$result1['name']." ".$result1['category']."</button>";
				echo "</div>";
				echo "<form action='main.php' method='post'>";
				echo "<div id='panel".$count."' class='panel' style='".$this->listBorder($result1['colour'])."'>";
			    $this->displayTasks($result1['id']);
			    echo "</div>";
			    echo "</form><br>";
			    $count++;
			}
		}

		$sql = "SELECT lists FROM users WHERE username = '$this->username'";
		$result = $this->connection->query($sql);
		$result1 = $result->fetch_assoc();
		
		if ($result1['lists'] < 5)
		{
			echo "<div class='newList'>";
			echo "<form action='main.php' method='post'>";
			echo "List Name:<br>";
			echo "<input type='text' name='name' required='true'><br>";
			echo "<div class='color'>";
			echo "List Colour:<br>";

			echo "<input type='text' name='colour' id='spec' required='true'><br>";
			echo "</div>";

			echo "<div class='category'>";
			echo "List Category:<br>";
			echo "<select name='category'>";
			echo "<option value='\u{1F6B2}'>Sport</option>";
			echo "<option value='\u{26F5}'>Sea Side</option>";
			echo "<option value='\u{26FD}'>Car</option>";
			echo "<option value='\u{1F339}'>Garden</option>";
			echo "<option value='\u{1F382}'>Birthday</option>";
			echo "<option value='\u{1F393}'>Education</option>";
			echo "<option value='\u{1F4B3}'>Shopping</option>";
			echo "</select><br>
			</div><br>";
			echo "<input type='submit' name='addList' value='Add List'>";
			echo "</form>";
			echo "</div>";
		}

	    echo "</div>";
	}

	private function getTaskID($listID, $content)
	{
		$sql = "SELECT id FROM tasks WHERE listID = '$listID' AND content = '$content'";
	$result = $this->connection->query($sql);
	$result1 = $result->fetch_assoc();
	
	return $result1['id'];
	}

	private function displayTasks($id)
	{
		$sql = "SELECT state, type, taskDate, taskTime, content FROM tasks WHERE listID = '$id'";
		$result = $this->connection->query($sql);
		
		if ($result->num_rows > 0)
		{
			echo "<table style='width:100%'";

			while ($result1 = $result->fetch_assoc())
			{
			    echo "<tr><td style='width:40%'>".$result1['content']."</td>";

			    if ($result1['type'] === "timer")
			    {
			    	echo "<td style='text-align:center'>".$result1['taskTime']."</td>";
			    }

			    else if ($result1['type'] === "deadline")
			    {
			    	echo "<td style='text-align:center'>".$result1['taskDate']."</td>";
			    }

			    else
			    {
			    	echo "<td style='text-align:center'></td>";
			    }

			    if ($result1['state'])
			    {
			    	echo "<td style='text-align:center'>Completed</td>";
			    	echo "<td style='text-align:right'><input type='submit' name='state".$this->getTaskID($id, $result1['content'])."' value='\u{274C}'style='max-width: 50px;'>";
			    }

			    else
			    {
			    	echo "<td style='text-align:center'>Incompleted</td>";
			    	echo "<td style='text-align:right'><input type='submit' name='state".$this->getTaskID($id, $result1['content'])."' value='\u{2714}'>";
			    }

			    echo "<input type='submit' name='removeTask".$this->getTaskID($id, $result1['content'])."' value='\u{1F5D1}'></td>";
			    echo "</tr>";
			    echo "<tr><td></td></tr>";
			    echo "<tr><td></td></tr>";
			    echo "<tr><td></td></tr>";
			    echo "<tr><td></td></tr>";
			}

			echo "</table>";
		}

		echo "<div class='task'>";
		echo "<br>Task:<br>";
		echo "<input type='text' name='content'>";
		echo "<button onclick='document.getElementById('content').value = ''>\u{274C}</button><br>";
		echo "<input type='hidden' name='listID' value='".$id."'>";
		echo "</div>";

		echo "<div class='type'>";
		echo "Type:<br>";
		echo "<select name='type' onchange='showHide(this)'>";
		echo "<option value='tick".$_SESSION["list"]."'>Tick</option>";
		echo "<option value='timer".$_SESSION["list"]."'>Timer</option>";
		echo "<option value='deadline".$_SESSION["list"]."'>Deadline</option>";
		echo "</select><br>";
		echo "</div>";

		echo "<div id='divDate".$_SESSION["list"]."'>Date:<br>";
		echo "<input type='date' name='taskDate' min='".date("Y-m-d")."'><br></div>";

		echo "<div id='divTime".$_SESSION["list"]."'>Time:<br>";
		echo "<input type='time' name='taskTime'><br></div>";

		echo "<table style='width:31%'><tr>";
		echo "<td style='width:16%'><input type='submit' name='addTask' value='Add Task'></td>";
		echo "<td style='width:15%'><input type='submit' name='removeList".$id."' value='Remove List'></td>";
		echo "</tr></table>";

		$_SESSION["list"] = $_SESSION["list"] + 1;
	}
}

class Member
{
	private $connection;
	private $username;
	private $password;

	function __construct($connection, $username, $password)
	{
		$this->connection = $connection;
		$this->username = $username;
		$this->password = $password;

		if ($this->checkPassword())
		{
			echo "Logged in successfully.\n";
		}

		else
		{
			session_destroy();
			header('Location: /Programming/MySQL/Jack(OOP)/index.html');
		}
	}

	private function checkPassword()
	{
		$sql = "SELECT username, password FROM users WHERE username='$this->username' AND password='$this->password'";
		$result = $this->connection->query($sql);
		
		if ($result->num_rows > 0)
		{
			if ($result1 = $result->fetch_assoc())
			{
				return true;
			}
		}

		return false;
	}
}

class Account
{
	private $connection;
	private $username;
	private $firstname;
	private $lastname;
	private $email;
	private $password;

	function __construct($connection, $username, $firstname, $lastname, $email, $password)
	{
		$this->connection = $connection;
		$this->username = $username;
		$this->firstname = $firstname;
		$this->lastname = $lastname;
		$this->email = $email;
		$this->password = $password;

		if ($this->checkUsername())
		{
			echo "Username already taken: $username\n";
		}

		else
		{
			if ($this->checkEmail())
			{
				echo "Email already in use: $email\n";
			}

			else
			{
				$sql = "INSERT INTO users (username, firstname, lastname, email, password, lists, points) VALUES ('$this->username', '$this->firstname', '$this->lastname', '$this->email', '$this->password', '0', '0')";

				if ($this->connection->query($sql) === TRUE)
				{
					echo "User added successfully.\n";
					return true;
				}

				else
				{
					echo "Error adding user: " . $this->connection->error."\n";
				}
			}
		}

		return false;
	}

	private function checkUsername()
	{
		$sql = "SELECT username FROM users";
		$result = $this->connection->query($sql);
		
		if ($result->num_rows > 0)
		{
			while ($result1 = $result->fetch_assoc())
			{
			    if($result1['username'] == $this->username)
			    {
			    	return true;
			    }
			}
		}

		return false;
	}

	private function checkEmail()
	{
		$sql = "SELECT email FROM users";
		$result = $this->connection->query($sql);
		
		if ($result->num_rows > 0)
		{
			while ($result1 = $result->fetch_assoc())
			{
			    if($result1['email'] == $this->email)
			    {
			    	return true;
			    }
			}
		}

		return false;
	}
}

class ToDoList
{
	private $username;
	private $connection;
	private $name;
	private $colour;
	private $category;

	function __construct($connection)
	{
		$this->username = $_SESSION["username"];
		$this->connection = $connection;
	}

	public function addList($name, $colour, $category)
	{
		$this->name = $name;
		$this->colour = $colour;
		$this->category = $category;

		$lists = $_SESSION["lists"] + 1;
		echo $lists;
		if ($lists >= 6)
		{
			echo "Maximum amount of lists available!\n"; 
		}

		else
		{	
			$sql = "INSERT INTO lists (id, username, name, colour, category) VALUES ('".$this->newID("lists")."', '$this->username', '$this->name', '$this->colour', '$this->category')";

		    if ($this->connection->query($sql) === TRUE)
		    {
			    echo "List added!\n";
			}

			$sql = "UPDATE users SET lists = '$lists' WHERE username = '$this->username'";

		    $this->connection->query($sql);
		}
	}

	public function removeList($id)
	{
		$lists = $this->getLists($this->connection, $this->username) - 1;

		if ($lists >= 0)
		{
			$sql = "DELETE FROM tasks WHERE listID = '".$id."'";

		    $this->connection->query($sql);

			$sql = "DELETE FROM lists WHERE username = '$this->username' AND id = '$id'";

		    if ($this->connection->query($sql) === TRUE)
		    {
			    echo "List removed!\n";
			}

			$sql = "UPDATE users SET lists = '$lists' WHERE username = '$this->username'";

		    $this->connection->query($sql);
		}
	}

	function getLists()
	{
		$sql = "SELECT lists FROM users WHERE username = '$this->username'";
		$result = $this->connection->query($sql);
		$result1 = $result->fetch_assoc();
		return $result1['lists'];
	}

	private function orderTable()
	{
		$sql = "ALTER TABLE lists ORDER BY id ASC";

		$this->connection->query($sql);
	}

	private function newID()
	{
		$this->orderTable();

		$currentID = 0;

		$sql = "SELECT id FROM lists";

		while(true)
		{
			$result = $this->connection->query($sql);

			if ($result->num_rows > 0)
			{
			    while($row = $result->fetch_assoc())
			    {
			        if ($row['id'] == $currentID)
			        {
			        	$currentID++;
			        }

			        else
			        {
			        	return $currentID;
			        }
			    }
			}

			else
			{
			    return 0;
			}
		}
	}
}

class Task
{
	private $connection;
	private $username;

	function __construct($connection)
	{
		$this->connection = $connection;
		$this->username = $_SESSION["username"];
	}

	public function addTask($listID, $type, $date, $time, $content)
	{
		$sql = "INSERT INTO tasks (id, listID, state, type, taskDate, taskTime, content) VALUES ('".$this->newID()."', '$listID', FALSE, '$type', '$date', '$time', '$content')";

		if ($this->connection->query($sql) === TRUE)
		{
			echo "Task added!\n";
		}

		else
		{
			echo "Error adding user: " . $this->connection->error."\n";
		}
	}

	public function removeTask($id)
	{
		$sql = "DELETE FROM tasks WHERE id = '$id'";

	    if ($this->connection->query($sql) === TRUE)
	    {
		    echo "Task removed!\n";
		}
	}

	public function getTaskState($id)
	{
		$sql = "SELECT state FROM tasks WHERE id = '$id'";
		$result = $this->connection->query($sql);
		$result1 = $result->fetch_assoc();
		
		if($result1['state'])
		{
			return 0;
		}

		return 1;
	}

	public function changeTaskState($id)
	{
		$state = $this->getTaskState($id);
		$sql = "UPDATE tasks SET state = '$state' WHERE id = '$id'";

	    if ($this->connection->query($sql) === TRUE)
	    {
		    echo "Task state changed!\n";

			if ($state)
			{
				$this->addPoints(10);
			}

			else
			{
				$this->removePoints(10);
			}
		}
	}

	private function getPoints()
	{
		$sql = "SELECT points FROM users WHERE username = '$this->username'";
		$result = $this->connection->query($sql);
		$result1 = $result->fetch_assoc();
		return $result1['points'];
	}

	private function addPoints($points)
	{
		$points = $this->getPoints() + $points;

		$sql = "UPDATE users SET points = '$points' WHERE username = '$this->username'";

	    if ($this->connection->query($sql) === TRUE)
	    {
		    echo "10 points added!\n";
		}
	}

	private function removePoints($points)
	{
		$points = $this->getPoints() - $points;

		$sql = "UPDATE users SET points = '$points' WHERE username = '$this->username'";

	    if ($this->connection->query($sql) === TRUE)
	    {
		    echo "10 points removed...\n";
		}
	}

	private function orderTable()
	{
		$sql = "ALTER TABLE tasks ORDER BY id ASC";

		$this->connection->query($sql);
	}

	private function newID()
	{
		$this->orderTable();

		$currentID = 0;

		$sql = "SELECT id FROM tasks";

		while(true)
		{
			$result = $this->connection->query($sql);

			if ($result->num_rows > 0)
			{
			    while($row = $result->fetch_assoc())
			    {
			        if ($row['id'] == $currentID)
			        {
			        	$currentID++;
			        }

			        else
			        {
			        	return $currentID;
			        }
			    }
			}

			else
			{
			    return 0;
			}
		}
	}
}

?>