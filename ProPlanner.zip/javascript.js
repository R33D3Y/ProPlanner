$(function() {
	$("#spec").spectrum({
        preferredFormat: "rgb",
        showInput: true,
        showPalette: true,
        palette: [["red", "rgba(0, 255, 0, .5)", "rgb(0, 0, 255)"]]
    });
});